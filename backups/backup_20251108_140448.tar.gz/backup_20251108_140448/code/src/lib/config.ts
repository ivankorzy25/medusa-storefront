export const medusaConfig = {
  baseUrl: process.env.NEXT_PUBLIC_MEDUSA_BACKEND_URL || "http://192.168.1.100:9000",
  publishableKey: process.env.NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY || "pk_92a7d2726b3934d0e55af93d4ebbf1a1ef7f82cec5fa81dc757a118e602d054c",
};
